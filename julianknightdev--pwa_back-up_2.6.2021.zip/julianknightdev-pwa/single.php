<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package julianknightdev-pwa
 */

get_header();
?>

<!-- Sidebar -->
<div class="w3-sidebar w3-animate-left w3-hide-medium w3-hide-small julianknightdev-yellow">
  <h4 class="w3-bar-item w3-container"><b>Menu</b></h4>
  <?php
			wp_nav_menu( array(

                                'container_class' => 'w3-bar-block',
                                'add_li_class' => 'w3-bar-item w3-button',
				'theme_location' => 'menu-2',
				'menu_id'        => 'mobile-menu',
			) );
			?>
</div>

<!-- Main content: shift it to the right by 250 pixels when the sidebar is visible -->
<div class="w3-main" style="margin-left:250px">


   <div class="w3-white responsive-top-pages">

	<main id="primary" class="site-main">

		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content', get_post_type() );

			the_post_navigation(
				array(
					'prev_text' => '<span class="nav-subtitle">' . esc_html__( 'Previous:', 'julianknightdev-pwa' ) . '</span> <div class="w3-margin-bottom"><span class="nav-title">%title</span></div>',
					'next_text' => '<span class="nav-subtitle">' . esc_html__( 'Next:', 'julianknightdev-pwa' ) . '</span> <div class="w3-margin-bottom"><span class="nav-title">%title</span></div>',
				)
			);

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		endwhile; // End of the loop.
		?>

	</main><!-- #main -->

</div>

</div>

<?php
get_sidebar();
get_footer();
