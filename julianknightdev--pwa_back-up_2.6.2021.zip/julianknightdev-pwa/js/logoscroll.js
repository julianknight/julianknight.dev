window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 25 || document.documentElement.scrollTop > 25) {
    document.getElementById("navimage").width = "48";
    document.getElementById("navname").style.fontSize = "30px";
  } else {
    document.getElementById("navimage").width = "64";
    document.getElementById("navname").style.fontSize = "36px";
  }
}